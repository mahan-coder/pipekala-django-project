from django.shortcuts import render
from django.views import View

# Create your views here.

class Product_page(View):
    def get(self,request):
        return render(request,'product/product.html')
