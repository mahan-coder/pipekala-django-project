from django.db import models

# Create your models here.

class Product(models.Model):
    main_type = models.CharField(max_length=100)
    _type =  models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    detail = models.CharField(max_length=150)
    img = models.ImageField()

    def __str__(self) -> str:
        return f'{self.pk}_ {self.main_type}'

    