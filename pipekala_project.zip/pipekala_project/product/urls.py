from django.urls import path
from .views import Product_page


urlpatterns = [
    path('',Product_page.as_view() ),
]
