from django.shortcuts import render
from django.views import View
# Create your views here.

class Contact_Us(View):
    def get(self,request):
        return render(request,'contact/contact.html')