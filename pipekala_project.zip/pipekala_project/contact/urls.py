from django.urls import path
from .views import Contact_Us


urlpatterns = [
    path('',Contact_Us.as_view()),
]
